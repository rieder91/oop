
package helper;

/**
 * possible event-notification status
 * 
 * @author OOP Gruppe 187
 * 
 * BAD: the enum's name is not accurate; it should be called SchedulingStatus instead
 */
public enum Status {
	scheduled, deferred, canceled
}
