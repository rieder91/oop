
package band;

/**
 * lists all possible types of infrastructur that a place can have
 * 
 * @author OOP Gruppe 187
 */
public enum Infrastructure {
	Hospital, PoliceStation, Toilet, PublicTransport, SuperMarket, LuxuryHotel, ParkingGarage, Stage, DemoRoom;
}
