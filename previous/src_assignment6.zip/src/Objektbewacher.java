
/**
 * ein objektbewache darf nur objektbewacher-software vom Level 4 verwenden
 * 
 * wenn er software vom level 4 hat, darf er kits mit <= 10 KW verwenden
 * 
 * @author OOP Gruppe 187
 *
 */
public class Objektbewacher extends Beschuetzer {

	/**
	 * default constructor
	 * @param seriennummer serial of the android
	 */
	public Objektbewacher(String seriennummer) {
		super(seriennummer);
	}

	protected void calledFromObjektbewacherSoftware(Software s) {
		s.getSecurityLevel().vonObjektbewacherVerwendetFuerSoftware(this, s);
		
	}
	
	protected void calledFromKaempferSoftware(Software s) {}
	protected void calledFromLeibwaechterSoftware(Software s) {}
	
	protected void calledFromSoftwareLevel4(Software s) { 
		super.installieren(s);
	}
	
	protected void calledFromSoftwareLevel5(Software s) {}
	
	protected void calledFromLeistungUnbegrenzt(SensorenAktorenKit s) {}

	
	public String toString() {
		return "Typ: Objektbewacher-Roboter" + super.toString();
	}
	
	public Android replaceRobotWith(Android android) {
		return android.replacedByObjektbewacher(android);
	}


}
