/**
 * testing interface implemented by all tester classes
 * @author OOP Gruppe 187
 *
 */
public interface Tester {
	
	/**
	 * runs all testcases
	 */
	public void runTests();
}
